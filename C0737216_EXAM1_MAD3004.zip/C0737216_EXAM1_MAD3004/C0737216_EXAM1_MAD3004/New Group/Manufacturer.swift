//
//  Manufacturer.swift
//  C0737216_EXAM1_MAD3004
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class manufacture
{
    var manufacturerid: Int!
    var manufacturername: String!
    
    init(manufacturerid: Int, manufacturername: String)
    {
        self.manufacturerid = manufacturerid
        self.manufacturername = manufacturername
    }
    
}
