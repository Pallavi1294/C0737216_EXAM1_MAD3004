//
//  util.swift
//  C0737216_EXAM1_MAD3004
//
//  Created by MacStudent on 2018-07-23.
//  Copyright © 2018 MacStudent. All rights reserved.
//

import Foundation
class util{
    getdate{
    
    }
}
